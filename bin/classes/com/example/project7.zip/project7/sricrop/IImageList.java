package com.example.project7.sricrop;

public interface IImageList {
	public int getcount();
	public IImage getImageAt(int i);
	public void close();

}
