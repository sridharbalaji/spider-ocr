package com.example.project7.sricrop;

import android.app.Activity;

	public class NoSearchActivity extends Activity {
		    @Override
		    public boolean onSearchRequested() {
		        return false;
		    }
		}
